package com.students.enrollment;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StudentsEnrollmentApplication {

	public static void main(String[] args) {
		SpringApplication.run(StudentsEnrollmentApplication.class, args);
		
	}

}
